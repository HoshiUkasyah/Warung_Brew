<?php
session_start();
include 'connect.php';
$id = (isset($_POST['id_list_order'])) ? htmlentities($_POST['id_list_order']) : "";
$catatan = (isset($_POST['catatan'])) ? htmlentities($_POST['catatan']) : "";

if (!empty($_POST['siap_saji_validate'])) {

    $query = mysqli_query($conn, "UPDATE tb_list_order SET catatan = '$catatan', status = 2 WHERE id_list_order = '$id'");
    if ($query) {
        $message = '<script>alert("Order siap disajikan");
                window.location="../dapur"</script>';
    } else {
        $message = '<script>alert("Gagal proses data");
            window.location="../dapur"</script>';
    }
}

echo $message;
?>